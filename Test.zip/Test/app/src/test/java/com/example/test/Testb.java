package com.example.test;

import android.util.Log;

import static java.lang.System.out;

public class Testb extends TestA{
    public void bb(){
        out.print("ni");
//       ni Log.e("ceshi2","ni");
    }
    public static void main(String[] args){
        TestA a=  new Testb();
        a.aa();
        String c="abc";
        c.toUpperCase();
        String b="a"+"b"+"c";
        out.print("测试"+c+"");
    }
}
