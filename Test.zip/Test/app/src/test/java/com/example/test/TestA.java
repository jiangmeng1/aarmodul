package com.example.test;

import android.util.Log;

import static java.lang.System.out;

public class TestA {

    public void aa(){
        bb();
    }

    public void bb(){
        out.print("wo");
//        Log.e("ceshi","wo");

    }
}
