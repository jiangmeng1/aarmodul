//package com.example.test;
//
//import android.os.MessageQueue;
//
//import java.util.ArrayDeque;
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Queue;
//import java.util.concurrent.ConcurrentLinkedQueue;
//import java.util.concurrent.locks.Condition;
//import java.util.concurrent.locks.Lock;
//import java.util.concurrent.locks.ReentrantLock;
//
//public class ProductionTest {
//
//    private List<String> list=new ArrayList<>();
//    private volatile int dt=0;
//    private int dp=0;
//    private ConcurrentLinkedQueue<String> queue=new ConcurrentLinkedQueue<>();
//
//    public synchronized void product(ProductionTest p){
//
//        while (queue.size()>10) {
//            try {
//                p.wait();
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//        }
////        list.add(p.getName()+dp);
//        dt++;
//        queue.add(dt+"");
//        dp++;
//        p.notify();
//    }
//    public synchronized void xiaofei(ProductionTest p){
//
//        while (queue.size()<=0) {
//            try {
//                p.wait();
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//        }
//
////        list.remove(p.getName());
//        dt--;
//        queue.remove(dt+"");
//        p.notify();
//    }
//
//    public static void main(String []args){
//        ProductionTest test=new ProductionTest();
//        ProductionTest test1=new ProductionTest();
//        Custem custem=new Custem(test);
//        Product product=new Product(test1);
//        Thread thread1=new Thread(custem);
//        Thread thread2=new Thread(product);
//
//        thread1.start();
//        thread2.start();
//
//        final Lock lock = new ReentrantLock();
//        final Condition empty = lock.newCondition();
//        final Condition full = lock.newCondition();
//
//        final int size = 10;
//        final Queue<String> queue = new ArrayDeque<String>(size);
//
//        Runnable runnable=new Runnable() {
//            @Override
//            public void run() {
//
//            }
//        };
//
//        Runnable producer = new Runnable() {
//
//            public void run() {
//                try {
//                    Thread.sleep(1);
//                } catch (InterruptedException e) {
//                    e.printStackTrace();
//                }
//                for(int i=0;i<20;i++) {
//                    lock.lock();
//                    try {
//                        if(queue.size() == size) {
//                            try {
//                                full.await();
//                            } catch (InterruptedException e) {
//                                e.printStackTrace();
//                            }
//                        }
//                        String msg = "生产消息:"+i;
//                        queue.add(msg);
//                        System.out.println(msg);
//                        empty.signal();
//                    } finally {
//                        lock.unlock();
//                    }
//                }
//            }
//        };
//
//        Runnable consumer = new Runnable() {
//            public void run() {
//                try {
//                    Thread.sleep(1);
//                } catch (InterruptedException e) {
//                    e.printStackTrace();
//                }
//                while (true) {
//                    lock.lock();
//                    try {
//                        if(queue.isEmpty()) {
//                            try {
//                                empty.await();
//                            } catch (InterruptedException e) {
//                                e.printStackTrace();
//                            }
//                        }else {
//                            String msg = queue.remove();
//                            System.out.println(msg + "已消费");
//                            full.signal();
//                        }
//                    } finally {
//                        lock.unlock();
//                    }
//                }
//            }
//        };
//
//        new Thread(consumer).start();
//        new Thread(consumer).start();
//        new Thread(producer).start();
//
//    }
//}
