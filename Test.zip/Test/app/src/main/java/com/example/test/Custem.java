//package com.example.test;
//
//import android.util.Log;
//
//public class Custem implements Runnable{
//    private ProductionTest pro;
//
//    public Custem(ProductionTest pro1){
//        pro  =pro1;
//    }
//    @Override
//    public void run() {
//
//        for (int i=0;i<10;i++){
//            System. out .println("jiangmeng消费 pro"+i);
//            try {
//                Thread.sleep(1000);
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//            pro.xiaofei(pro);
//        }
//    }
//}
