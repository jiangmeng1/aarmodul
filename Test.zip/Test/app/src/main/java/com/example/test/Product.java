//package com.example.test;
//
//import android.util.Log;
//
//public class Product implements Runnable{
//    private ProductionTest pro;
//
//    public Product(ProductionTest pro1){
//        pro  =pro1;
//    }
//    @Override
//    public void run() {
//
//        for (int i=0;i<10;i++){
//            System. out .println("jiangmeng生产 pro"+i);
//            try {
//                Thread.sleep(3000);
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//            pro.product(pro);
//
//        }
//    }
//}