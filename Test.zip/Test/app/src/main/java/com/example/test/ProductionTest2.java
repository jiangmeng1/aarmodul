//package com.example.test;
//
//import java.util.ArrayDeque;
//import java.util.Queue;
//import java.util.concurrent.locks.Condition;
//import java.util.concurrent.locks.Lock;
//import java.util.concurrent.locks.ReentrantLock;
//
//public class ProductionTest2 {
////    private Queue<String> queue=new ArrayDeque<>();
//    public static void main(String []args){
//        final Queue<String> queue=new ArrayDeque<>();
//        final Lock lock=new ReentrantLock();
//       final Condition empty=lock.newCondition();
//        final Condition full=lock.newCondition();
//        Runnable runnable=new Runnable() {
//            @Override
//            public void run() {
//                lock.lock();
//                try {
//                    while (queue.size()==10){
//                        empty.await();
//                    }
//                    queue.poll();
//                    System.out.println("从队列取走一个元素，队列剩余"+queue.size()+"个元素");
//                    full.signal();
//                }catch (Exception e){
//                    lock.unlock();
//                }
//            }
//        };
//        Runnable runnable1=new Runnable() {
//            @Override
//            public void run() {
//                lock.lock();
//                try {
//                    while (queue.size()==10){
//                        full.await();
//                    }
//                    queue.offer("1");
//                    System.out.println("向队列取中插入一个元素，队列剩余空间："+(10-queue.size()));
//                    empty.signal();
//                }catch (Exception e){
//                    lock.unlock();
//                }
//            }
//        };
////        new Thread(runnable).start();
//        new Thread(runnable).start();
//        new Thread(runnable1).start();
//    }
//}
