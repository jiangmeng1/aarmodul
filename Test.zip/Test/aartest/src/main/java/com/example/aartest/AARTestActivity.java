package com.example.aartest;

import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.alibaba.fastjson.JSONObject;


public class AARTestActivity extends AppCompatActivity {
private TextView text;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mainaar);
        text=findViewById(R.id.text);
        JSONObject jsonObject=new JSONObject();
        Bundle bundle = getIntent().getExtras();
        if (bundle != null){ //防止直接启动MainActivity时空指针闪退
            String value = bundle.getString("userinfo");
            text.setText(value);
        }
        text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.putExtra("userinfo", "jiangmeng");
                ComponentName componetName = new ComponentName("com.example.test","com.example.mylibrary.MainActivity");
                intent.setComponent(componetName);
                startActivity(intent);
            }
        });
    }
}
